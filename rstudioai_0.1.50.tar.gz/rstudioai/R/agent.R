# RgentAI Agent Functions
# Specialized agent functionality for autonomous R workflows

#' Get Available DataFrames in Global Environment
#' @return Character vector of DataFrame names
get_available_dataframes <- function() {
  tryCatch({
    env_objects <- ls(envir = .GlobalEnv)
    dataframes <- character(0)
    
    for (obj_name in env_objects) {
      obj <- get(obj_name, envir = .GlobalEnv)
      if (is.data.frame(obj)) {
        dataframes <- c(dataframes, obj_name)
      }
    }
    
    return(dataframes)
  }, error = function(e) {
    return(character(0))
  })
}

#' Get Basic Information About a DataFrame
#' @param df_name Name of the DataFrame
#' @return List with DataFrame information
get_dataframe_info <- function(df_name) {
  if (!exists(df_name, envir = .GlobalEnv)) {
    return(list(
      exists = FALSE,
      error = paste("DataFrame", df_name, "not found")
    ))
  }
  
  tryCatch({
    df <- get(df_name, envir = .GlobalEnv)
    
    if (!is.data.frame(df)) {
      return(list(
        exists = FALSE,
        error = paste(df_name, "is not a data.frame")
      ))
    }
    
    # Get column information
    col_info <- sapply(df, function(x) {
      list(
        type = class(x)[1],
        missing = sum(is.na(x)),
        unique_values = length(unique(x))
      )
    }, simplify = FALSE)
    
    return(list(
      exists = TRUE,
      name = df_name,
      nrow = nrow(df),
      ncol = ncol(df),
      columns = names(df),
      column_info = col_info,
      size_mb = round(as.numeric(object.size(df)) / 2^20, 2)
    ))
  }, error = function(e) {
    return(list(
      exists = FALSE,
      error = paste("Error analyzing", df_name, ":", e$message)
    ))
  })
}

#' Enhanced Context Capture for Agent Execution
#' @return List with current R environment state optimized for agents
capture_agent_context <- function() {
  base_context <- capture_context()  # Reuse existing function
  
  # Add agent-specific information
  agent_context <- list(
    base_context = base_context,
    available_dataframes = get_available_dataframes(),
    dataframe_info = list()
  )
  
  # Get info for each available DataFrame (lightweight summary only)
  for (df_name in agent_context$available_dataframes) {
    df_info <- get_dataframe_info(df_name)
    if (df_info$exists) {
      # Store only essential info to minimize token usage
      agent_context$dataframe_info[[df_name]] <- list(
        nrow = df_info$nrow,
        ncol = df_info$ncol,
        columns = df_info$columns,
        missing_counts = sapply(df_info$column_info, function(x) x$missing)
      )
    }
  }
  
  return(agent_context)
}

#' Execute Cleaning Agent Workflow
#' @param dataframe Name of the DataFrame to clean
#' @param na_handling Method for handling NAs: "dont", "mean", "median", "mode", "remove"
#' @param step Current step number
#' @return List with execution results
execute_cleaning_agent <- function(dataframe, na_handling = "median", step = 1) {
  # Validate DataFrame exists
  if (!exists(dataframe, envir = globalenv())) {
    return(list(
      success = FALSE,
      error = paste("DataFrame", dataframe, "not found in environment")
    ))
  }
  
  # Get workflow steps
  workflow_steps <- get_cleaning_workflow_steps()
  
  # Validate step number
  if (step < 1 || step > length(workflow_steps)) {
    return(list(
      success = FALSE,
      error = paste("Invalid step number:", step, "- must be between 1 and", length(workflow_steps))
    ))
  }
  
  # Get the current step info
  step_info <- workflow_steps[[step]]
  
  # Load execution settings
  settings <- load_execution_settings()
  
  # Execute the workflow step using our proven execution engine
  result <- execute_workflow_step(step_info, dataframe, na_handling, settings)
  
  # Add completion status
  result$completed <- (step == length(workflow_steps))
  result$next_step <- if (!result$completed) step + 1 else NULL
  
  return(result)
}

#' Generate NA Handling Code
#' @param dataframe Name of the DataFrame
#' @param method Method for handling NAs
#' @param df_info DataFrame information
#' @return Character string with R code
generate_na_handling_code <- function(dataframe, method, df_info) {
  if (method == "dont") {
    return(paste0("# No NA handling requested"))
  }
  
  # Find columns with missing values
  cols_with_nas <- names(df_info$column_info)[
    sapply(df_info$column_info, function(x) x$missing > 0)
  ]
  
  if (length(cols_with_nas) == 0) {
    return(paste0("# No missing values found in ", dataframe))
  }
  
  if (method == "remove") {
    return(paste0(dataframe, " <- ", dataframe, "[complete.cases(", dataframe, "), ]"))
  }
  
  # Generate code for each column with NAs
  code_lines <- c()
  for (col in cols_with_nas) {
    col_type <- df_info$column_info[[col]]$type
    
    if (col_type %in% c("numeric", "integer")) {
      if (method == "mean") {
        code_lines <- c(code_lines, 
          paste0(dataframe, "$", col, "[is.na(", dataframe, "$", col, ")] <- mean(", 
                 dataframe, "$", col, ", na.rm = TRUE)"))
      } else if (method == "median") {
        code_lines <- c(code_lines,
          paste0(dataframe, "$", col, "[is.na(", dataframe, "$", col, ")] <- median(", 
                 dataframe, "$", col, ", na.rm = TRUE)"))
      }
    } else if (col_type %in% c("character", "factor")) {
      if (method == "mode") {
        code_lines <- c(code_lines,
          paste0("mode_val <- names(sort(table(", dataframe, "$", col, "), decreasing = TRUE))[1]; ",
                 dataframe, "$", col, "[is.na(", dataframe, "$", col, ")] <- mode_val"))
      }
    }
  }
  
  if (length(code_lines) == 0) {
    return(paste0("# No suitable columns for ", method, " imputation"))
  }
  
  return(paste(code_lines, collapse = "; "))
}

#' Generate Data Type Conversion Code
#' @param dataframe Name of the DataFrame
#' @param df_info DataFrame information
#' @return Character string with R code
generate_type_conversion_code <- function(dataframe, df_info) {
  # This is a simplified version - in practice, you'd want more sophisticated detection
  code_lines <- c()
  
  for (col in names(df_info$column_info)) {
    col_info <- df_info$column_info[[col]]
    
    # Example: Convert character columns that look like numbers
    if (col_info$type == "character" && col_info$unique_values < (df_info$nrow * 0.8)) {
      code_lines <- c(code_lines,
        paste0("# Consider converting ", col, " to factor if appropriate"))
    }
  }
  
  if (length(code_lines) == 0) {
    return(paste0("# Data types look appropriate for ", dataframe))
  }
  
  return(paste(code_lines, collapse = "; "))
}

#' Generate Outlier Removal Code
#' @param dataframe Name of the DataFrame
#' @param df_info DataFrame information
#' @return Character string with R code
generate_outlier_removal_code <- function(dataframe, df_info) {
  # Find numeric columns
  numeric_cols <- names(df_info$column_info)[
    sapply(df_info$column_info, function(x) x$type %in% c("numeric", "integer"))
  ]
  
  if (length(numeric_cols) == 0) {
    return(paste0("# No numeric columns found for outlier removal in ", dataframe))
  }
  
  # For simplicity, apply IQR method to all numeric columns
  code_lines <- c()
  for (col in numeric_cols) {
    code_lines <- c(code_lines,
      paste0("Q1_", col, " <- quantile(", dataframe, "$", col, ", 0.25, na.rm = TRUE); ",
             "Q3_", col, " <- quantile(", dataframe, "$", col, ", 0.75, na.rm = TRUE); ",
             "IQR_", col, " <- Q3_", col, " - Q1_", col, "; ",
             dataframe, " <- ", dataframe, "[", dataframe, "$", col, " >= Q1_", col, " - 1.5*IQR_", col, 
             " & ", dataframe, "$", col, " <= Q3_", col, " + 1.5*IQR_", col, " | is.na(", dataframe, "$", col, "), ]"))
  }
  
  return(paste(code_lines, collapse = "; "))
}

#' Start Cleaning Agent Workflow
#' @param dataframe Name of the DataFrame to clean
#' @param na_handling Method for handling NAs
#' @param cleaning_options List of cleaning operations to perform
#' @return List with workflow information
start_cleaning_agent <- function(dataframe, na_handling = "median", cleaning_options = NULL) {
  # Validate DataFrame exists
  if (!exists(dataframe, envir = globalenv())) {
    return(list(
      success = FALSE,
      error = paste("DataFrame", dataframe, "not found")
    ))
  }
  
  # Default cleaning options if not provided
  if (is.null(cleaning_options)) {
    cleaning_options <- list(
      dataTypes = TRUE,
      missingValues = TRUE,
      duplicates = TRUE,
      outliers = TRUE,
      columnNames = TRUE
    )
  }
  
  # Build dynamic workflow based on selected options
  workflow_steps <- list()
  step_num <- 1
  
  if (cleaning_options$dataTypes) {
    workflow_steps[[step_num]] <- list(
      step = step_num,
      description = "📊 Examine data types and structure",
      operation = "data_types"
    )
    step_num <- step_num + 1
  }
  
  if (cleaning_options$missingValues) {
    workflow_steps[[step_num]] <- list(
      step = step_num,
      description = "⚠️ Analyze missing values patterns",
      operation = "missing_values"
    )
    step_num <- step_num + 1
  }
  
  if (cleaning_options$duplicates) {
    workflow_steps[[step_num]] <- list(
      step = step_num,
      description = "🔄 Detect duplicate records",
      operation = "duplicates"
    )
    step_num <- step_num + 1
  }
  
  if (cleaning_options$outliers) {
    workflow_steps[[step_num]] <- list(
      step = step_num,
      description = "📈 Identify outliers using IQR method",
      operation = "outliers"
    )
    step_num <- step_num + 1
  }
  
  if (cleaning_options$columnNames) {
    workflow_steps[[step_num]] <- list(
      step = step_num,
      description = "🏷️ Standardize column names to snake_case",
      operation = "column_names"
    )
    step_num <- step_num + 1
  }
  
  if (length(workflow_steps) == 0) {
    return(list(
      success = FALSE,
      message = "No cleaning operations selected",
      error = "Please select at least one cleaning operation"
    ))
  }
  
  return(list(
    success = TRUE,
    message = "Data Cleaning Agent started successfully",
    workflow_id = paste0("cleaning_", Sys.time()),
    dataframe = dataframe,
    na_handling = na_handling,
    cleaning_options = cleaning_options,
    workflow_steps = workflow_steps,
    current_step = workflow_steps[[1]],
    total_steps = length(workflow_steps)
  ))
}
