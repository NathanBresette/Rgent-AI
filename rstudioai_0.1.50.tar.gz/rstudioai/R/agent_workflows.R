#' AI Agent Workflows
#' 
#' This module defines the workflow steps and execution logic for AI agents,
#' using the proven execution engine for reliable code execution.

#' Data Cleaning Agent Workflow Steps
#'
#' @return List of workflow steps for data cleaning
get_cleaning_workflow_steps <- function() {
  list(
    list(
      step = 1,
      description = "🔍 Analyze data structure and types",
      operation = "data_types",
      code_template = "cat('Data Types Analysis\\n')\nstr({dataframe})\nsapply({dataframe}, class)"
    ),
    list(
      step = 2,
      description = "🔄 Detect duplicate records",
      operation = "duplicates",
      code_template = "cat('Duplicate Analysis\\n')\ncat('Total duplicates:', sum(duplicated({dataframe})), '\\n')\ncat('Duplicate rows:', nrow({dataframe}[duplicated({dataframe}), ]), '\\n')"
    ),
    list(
      step = 3,
      description = "📈 Identify outliers using IQR method",
      operation = "outliers",
      code_template = "cat('Outlier Analysis\\n')\nnumeric_cols <- sapply({dataframe}, is.numeric)\nif(any(numeric_cols)) {\n  for(col in names({dataframe})[numeric_cols]) {\n    Q1 <- quantile({dataframe}[[col]], 0.25, na.rm = TRUE)\n    Q3 <- quantile({dataframe}[[col]], 0.75, na.rm = TRUE)\n    IQR <- Q3 - Q1\n    outliers <- sum({dataframe}[[col]] < Q1 - 1.5*IQR | {dataframe}[[col]] > Q3 + 1.5*IQR, na.rm = TRUE)\n    cat(col, ':', outliers, 'outliers\\n')\n  }\n} else {\n  cat('No numeric columns for outlier analysis\\n')\n}"
    ),
    list(
      step = 4,
      description = "🏷️ Standardize column names to snake_case",
      operation = "column_names",
      code_template = "cat('Column Names Analysis\\n')\ncat('Current names:', paste(names({dataframe}), collapse=', '), '\\n')\nsuggested_names <- gsub('[^A-Za-z0-9_]', '_', tolower(names({dataframe})))\nsuggested_names <- gsub('_+', '_', suggested_names)\nsuggested_names <- gsub('^_|_$', '', suggested_names)\ncat('Suggested names:', paste(suggested_names, collapse=', '), '\\n')"
    )
  )
}

#' Generate code for a specific workflow step
#'
#' @param step_info Step information from workflow
#' @param dataframe Name of the dataframe to work with
#' @param na_handling How to handle NA values
#' @return Generated R code for the step
generate_step_code <- function(step_info, dataframe, na_handling) {
  operation <- step_info$operation
  
  switch(operation,
    "data_types" = {
      paste0("cat('Data Types Analysis\\n')\n", "str(", dataframe, ")\n", "sapply(", dataframe, ", class)")
    },
    "duplicates" = {
      paste0("cat('Duplicate Analysis\\n')\n", "cat('Total duplicates:', sum(duplicated(", dataframe, ")), '\\n')\n", "cat('Duplicate rows:', nrow(", dataframe, "[duplicated(", dataframe, "), ]), '\\n')")
    },
    "outliers" = {
      paste0("cat('Outlier Analysis\\n')\n", "numeric_cols <- sapply(", dataframe, ", is.numeric)\n", "if(any(numeric_cols)) {\n  for(col in names(", dataframe, ")[numeric_cols]) {\n    Q1 <- quantile(", dataframe, "[[col]], 0.25, na.rm = TRUE)\n    Q3 <- quantile(", dataframe, "[[col]], 0.75, na.rm = TRUE)\n    IQR <- Q3 - Q1\n    outliers <- sum(", dataframe, "[[col]] < Q1 - 1.5*IQR | ", dataframe, "[[col]] > Q3 + 1.5*IQR, na.rm = TRUE)\n    cat(col, ':', outliers, 'outliers\\n')\n  }\n} else {\n  cat('No numeric columns for outlier analysis\\n')\n}")
    },
    "column_names" = {
      paste0("cat('Column Names Analysis\\n')\n", "cat('Current names:', paste(names(", dataframe, "), collapse=', '), '\\n')\n", "suggested_names <- gsub('[^A-Za-z0-9_]', '_', tolower(names(", dataframe, ")))\n", "suggested_names <- gsub('_+', '_', suggested_names)\n", "suggested_names <- gsub('^_|_$', '', suggested_names)\n", "cat('Suggested names:', paste(suggested_names, collapse=', '), '\\n')")
    },
    # Default case
    step_info$code_template
  )
}

#' Execute a workflow step
#'
#' @param step_info Step information
#' @param dataframe Name of the dataframe
#' @param na_handling How to handle NA values
#' @param settings Execution settings
#' @return Execution result
execute_workflow_step <- function(step_info, dataframe, na_handling, settings = NULL) {
  # Generate code for this step
  code <- generate_step_code(step_info, dataframe, na_handling)
  
  # Execute the code using our proven execution engine
  result <- execute_code_in_session(code, settings)
  
  # Return structured result
  list(
    step = step_info$step,
    description = step_info$description,
    operation = step_info$operation,
    code = code,
    success = result$success,
    output = result$output,
    error = if(!result$success) result$error else NULL,
    plot = result$plot
  )
}

#' Get available dataframes in the environment
#'
#' @return List of available dataframes
get_available_dataframes <- function() {
  # Get all objects in global environment
  objects <- ls(envir = .GlobalEnv)
  
  # Filter for dataframes
  dataframes <- c()
  for(obj in objects) {
    if(exists(obj, envir = .GlobalEnv)) {
      value <- get(obj, envir = .GlobalEnv)
      if(is.data.frame(value)) {
        dataframes <- c(dataframes, obj)
      }
    }
  }
  
  return(dataframes)
}

#' Get dataframe information
#'
#' @param dataframe_name Name of the dataframe
#' @return Dataframe information
get_dataframe_info <- function(dataframe_name) {
  if(!exists(dataframe_name, envir = .GlobalEnv)) {
    return(list(error = "Dataframe not found"))
  }
  
  df <- get(dataframe_name, envir = .GlobalEnv)
  if(!is.data.frame(df)) {
    return(list(error = "Object is not a dataframe"))
  }
  
  # Check for missing values
  missing_counts <- sapply(df, function(x) sum(is.na(x)))
  has_missing <- any(missing_counts > 0)
  
  list(
    name = dataframe_name,
    rows = nrow(df),
    columns = ncol(df),
    column_names = names(df),
    column_types = sapply(df, class),
    missing_values = missing_counts,
    has_missing = has_missing,
    total_missing = sum(missing_counts)
  )
}
