#' Utility Functions
#' 
#' This module contains helper functions used across the agent system.

#' Check if a package is available
#'
#' @param package Package name
#' @return TRUE if package is available, FALSE otherwise
is_package_available <- function(package) {
  requireNamespace(package, quietly = TRUE)
}

#' Safe JSON conversion
#'
#' @param obj Object to convert to JSON
#' @return JSON string or error message
safe_to_json <- function(obj) {
  tryCatch({
    jsonlite::toJSON(obj, auto_unbox = TRUE, force = TRUE)
  }, error = function(e) {
    paste("Error converting to JSON:", e$message)
  })
}

#' Safe JSON parsing
#'
#' @param json JSON string to parse
#' @return Parsed object or NULL on error
safe_from_json <- function(json) {
  tryCatch({
    jsonlite::fromJSON(json)
  }, error = function(e) {
    warning("Error parsing JSON:", e$message)
    NULL
  })
}

#' Format execution time
#'
#' @param start_time Start time
#' @param end_time End time
#' @return Formatted time difference
format_execution_time <- function(start_time, end_time) {
  diff <- as.numeric(difftime(end_time, start_time, units = "secs"))
  if(diff < 1) {
    paste(round(diff * 1000, 1), "ms")
  } else if(diff < 60) {
    paste(round(diff, 2), "seconds")
  } else {
    paste(round(diff / 60, 2), "minutes")
  }
}

#' Validate dataframe name
#'
#' @param name Dataframe name to validate
#' @return TRUE if valid, FALSE otherwise
is_valid_dataframe_name <- function(name) {
  if(is.null(name) || length(name) == 0) return(FALSE)
  if(!is.character(name)) return(FALSE)
  if(length(name) > 1) return(FALSE)
  if(nchar(name) == 0) return(FALSE)
  TRUE
}

#' Sanitize dataframe name
#'
#' @param name Dataframe name to sanitize
#' @return Sanitized name
sanitize_dataframe_name <- function(name) {
  # Remove special characters
  gsub("[^a-zA-Z0-9_.]", "", name)
}

#' Get R session info
#'
#' @return List of R session information
get_session_info <- function() {
  list(
    r_version = as.character(R.version.string),
    platform = R.version$platform,
    os_type = .Platform$OS.type,
    working_directory = getwd(),
    timestamp = Sys.time()
  )
}

#' Create unique ID
#'
#' @param prefix Prefix for the ID
#' @return Unique ID string
create_unique_id <- function(prefix = "id") {
  timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S_%f")
  random_suffix <- sample(1000:9999, 1)
  paste0(prefix, "_", timestamp, "_", random_suffix)
}

#' Check if object exists and is a dataframe
#'
#' @param name Object name
#' @return TRUE if exists and is dataframe, FALSE otherwise
is_dataframe <- function(name) {
  if(!exists(name, envir = .GlobalEnv)) return(FALSE)
  obj <- get(name, envir = .GlobalEnv)
  is.data.frame(obj)
}

#' Get object size in human readable format
#'
#' @param obj Object to measure
#' @return Human readable size string
get_object_size <- function(obj) {
  size <- object.size(obj)
  if(size < 1024) {
    paste(size, "bytes")
  } else if(size < 1024^2) {
    paste(round(size / 1024, 1), "KB")
  } else if(size < 1024^3) {
    paste(round(size / 1024^2, 1), "MB")
  } else {
    paste(round(size / 1024^3, 1), "GB")
  }
}
