# Modeling Agent for RStudio AI
# Provides comprehensive machine learning with model interpretability

#' Start Modeling Agent
#' @param dataframe_name Name of the dataframe to analyze
#' @param problem_type Type of problem (classification, regression, clustering, dimensionality_reduction)
#' @param target_variable Target variable for supervised learning
#' @param algorithms List of selected algorithms
#' @param options List of additional options
#' @return List with workflow steps and initial analysis
start_modeling_agent <- function(dataframe_name, target_variable, algorithms, options) {
  tryCatch({
    # Load required packages
    required_packages <- c("dplyr", "ggplot2", "caret", "randomForest", "xgboost", "e1071", 
                          "rpart", "nnet", "MASS", "stats", "Rtsne", "umap", "shapviz")
    load_packages(required_packages)
    
    # Get the dataframe
    df <- get(dataframe_name, envir = .GlobalEnv)
    
    # Validate dataframe
    if (!is.data.frame(df)) {
      stop("Selected object is not a dataframe")
    }
    
      # Create workflow steps based on selected algorithms
  workflow_steps <- create_modeling_workflow(algorithms, options, dataframe_name, target_variable)
    
    # Return workflow information (don't execute first step yet - let frontend handle it)
    list(
      success = TRUE,
      dataframe = dataframe_name,
      target_variable = target_variable,
      algorithms = algorithms,
      options = options,
      workflow_steps = workflow_steps,
      current_step = list(
        step = 1,
        operation = workflow_steps[[1]]$operation,
        description = workflow_steps[[1]]$description,
        code = workflow_steps[[1]]$code
      ),
      total_steps = length(workflow_steps),
      message = "Modeling agent started successfully"
    )
    
  }, error = function(e) {
    list(
      success = FALSE,
      error = e$message,
      message = paste("Failed to start modeling agent:", e$message)
    )
  })
}

#' Create Modeling Workflow Steps
#' @param algorithms Selected algorithms
#' @param options Additional options
#' @param dataframe_name Name of the dataframe
#' @param target_variable_name Name of the target variable
#' @return List of workflow steps
create_modeling_workflow <- function(algorithms, options, dataframe_name, target_variable_name) {
  steps <- list()
  step_counter <- 1
  
  # Data Overview Step
  steps[[step_counter]] <- list(
    step = step_counter,
    operation = "data_overview",
    description = "Analyzing data structure and preparing for modeling",
    code = paste0("execute_modeling_data_overview(", dataframe_name, ", '", target_variable_name, "')")
  )
  step_counter <- step_counter + 1
  
  # Data Preprocessing Step
  steps[[step_counter]] <- list(
    step = step_counter,
    operation = "data_preprocessing",
    description = "Handling missing values, encoding categorical variables, scaling",
    code = paste0("execute_data_preprocessing(", dataframe_name, ", '", target_variable_name, "')")
  )
  step_counter <- step_counter + 1
  
  # Feature Engineering Step
  if (options$featureEngineering) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "feature_engineering",
      description = "Creating new features and selecting important variables",
      code = paste0("execute_feature_engineering(", dataframe_name, ", '", target_variable_name, "', options)")
    )
    step_counter <- step_counter + 1
  }
  
  # Dimensionality Reduction Step
  if (algorithms$dimensionalityReduction) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "dimensionality_reduction",
      description = "Applying PCA, t-SNE, or UMAP for dimension reduction",
      code = paste0("execute_dimensionality_reduction(", dataframe_name, ", options)")
    )
    step_counter <- step_counter + 1
  }
  
  # Model Training Steps
  if (algorithms$linearRegression) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "linear_regression",
      description = "Training linear regression model with interpretability",
      code = paste0("execute_linear_regression(", dataframe_name, ", '", target_variable_name, "', options)")
    )
    step_counter <- step_counter + 1
  }
  
  if (algorithms$logisticRegression) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "logistic_regression",
      description = "Training logistic regression model with interpretability",
      code = paste0("execute_logistic_regression(", dataframe_name, ", '", target_variable_name, "', options)")
    )
    step_counter <- step_counter + 1
  }
  
  if (algorithms$multinomialRegression) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "multinomial_regression",
      description = "Training multinomial regression model with interpretability",
      code = paste0("execute_multinomial_regression(", dataframe_name, ", '", target_variable_name, "', options)")
    )
    step_counter <- step_counter + 1
  }
  
  if (algorithms$randomForest) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "random_forest",
      description = "Training random forest model with interpretability",
      code = paste0("execute_random_forest(", dataframe_name, ", '", target_variable_name, "', options)")
    )
    step_counter <- step_counter + 1
  }
  
  if (algorithms$xgboost) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "xgboost",
      description = "Training XGBoost model with interpretability",
      code = paste0("execute_xgboost(", dataframe_name, ", '", target_variable_name, "', options)")
    )
    step_counter <- step_counter + 1
  }
  
  # Model Comparison Step
  if (length(algorithms) > 1) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "model_comparison",
      description = "Comparing model performance and generating insights",
      code = paste0("execute_model_comparison(", dataframe_name, ", '", target_variable_name, "', algorithms)")
    )
    step_counter <- step_counter + 1
  }
  
  # Results Compilation Step
  steps[[step_counter]] <- list(
    step = step_counter,
    operation = "results_compilation",
    description = "Compiling final results and generating comprehensive report",
    code = paste0("execute_results_compilation(", dataframe_name, ", '", target_variable_name, "', algorithms)")
  )
  
  return(steps)
}

#' Execute Modeling Step
#' @param df Dataframe to analyze
#' @param step_info Step information
#' @param target_variable Target variable for supervised learning
#' @param algorithms Selected algorithms
#' @param options Additional options
#' @return Step execution result
execute_modeling_step <- function(df, step_info, target_variable, algorithms, options) {
  tryCatch({
    operation <- step_info$operation
    
    switch(operation,
      "data_overview" = execute_modeling_data_overview(df, target_variable),
      "data_preprocessing" = execute_data_preprocessing(df, target_variable),
      "feature_engineering" = execute_feature_engineering(df, target_variable, options),
      "dimensionality_reduction" = execute_dimensionality_reduction(df, options),
      "linear_regression" = execute_linear_regression(df, target_variable, options),
      "logistic_regression" = execute_logistic_regression(df, target_variable, options),
      "multinomial_regression" = execute_multinomial_regression(df, target_variable, options),
      "random_forest" = execute_random_forest(df, target_variable, options),
      "xgboost" = execute_xgboost(df, target_variable, options),
      "model_comparison" = execute_model_comparison(df, target_variable, algorithms),
      "results_compilation" = execute_results_compilation(df, target_variable, algorithms),
      stop("Unknown operation: ", operation)
    )
    
  }, error = function(e) {
    list(
      success = FALSE,
      error = e$message,
      step = step_info$step,
      operation = operation
    )
  })
}

#' Execute Modeling Data Overview Step
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @return Data overview results
execute_modeling_data_overview <- function(df, target_variable) {
  tryCatch({
    # Validate inputs
    if (is.null(df)) {
      stop("Dataframe is NULL")
    }
    if (!is.data.frame(df)) {
      stop("Input is not a dataframe")
    }
    if (is.null(target_variable)) {
      stop("Target variable is NULL")
    }
    if (!is.character(target_variable)) {
      stop("Target variable must be a character string")
    }
    if (!target_variable %in% names(df)) {
      stop(paste("Target variable '", target_variable, "' not found in dataframe"))
    }
    
    # Basic structure information
    structure_info <- list(
      dimensions = dim(df),
      variable_count = ncol(df),
      observation_count = nrow(df),
      memory_usage = as.numeric(object.size(df))
    )
  
  # Variable types and summary
  variable_info <- list()
  for (col in names(df)) {
    if (is.numeric(df[[col]])) {
      # Convert summary to simple list
      summary_obj <- summary(df[[col]])
      variable_info[[col]] <- list(
        type = "numeric",
        summary = list(
          min = as.numeric(summary_obj[1]),
          q1 = as.numeric(summary_obj[2]),
          median = as.numeric(summary_obj[3]),
          mean = as.numeric(summary_obj[4]),
          q3 = as.numeric(summary_obj[5]),
          max = as.numeric(summary_obj[6])
        ),
        missing_count = sum(is.na(df[[col]])),
        unique_count = length(unique(df[[col]]))
      )
    } else {
      variable_info[[col]] <- list(
        type = "categorical",
        levels = as.character(levels(factor(df[[col]]))),
        missing_count = sum(is.na(df[[col]])),
        unique_count = length(unique(df[[col]]))
      )
    }
  }
  
  # Target variable analysis
  target_analysis <- NULL
  if (!is.null(target_variable) && target_variable %in% names(df)) {
    target_data <- df[[target_variable]]
    if (is.numeric(target_data)) {
      # Convert summary to simple list
      summary_obj <- summary(target_data)
      target_analysis <- list(
        type = "numeric",
        distribution = list(
          min = as.numeric(summary_obj[1]),
          q1 = as.numeric(summary_obj[2]),
          median = as.numeric(summary_obj[3]),
          mean = as.numeric(summary_obj[4]),
          q3 = as.numeric(summary_obj[5]),
          max = as.numeric(summary_obj[6])
        ),
        missing_count = sum(is.na(target_data)),
        is_balanced = TRUE  # Will be updated based on actual distribution
      )
    } else {
      # Convert table to simple list
      table_obj <- table(target_data)
      target_analysis <- list(
        type = "categorical",
        levels = as.character(levels(factor(target_data))),
        distribution = as.list(table_obj),
        missing_count = sum(is.na(target_data)),
        is_balanced = length(unique(target_data)) == 2 && 
                     min(table_obj) / max(table_obj) > 0.3
      )
    }
  }
  
  list(
    success = TRUE,
    operation = "data_overview",
    structure_info = structure_info,
    variable_info = variable_info,
    target_analysis = target_analysis,
    message = "Data overview completed successfully"
  )
  }, error = function(e) {
    list(
      success = FALSE,
      operation = "data_overview",
      error = e$message,
      message = paste("Data overview failed:", e$message)
    )
  })
}

#' Execute Data Preprocessing Step
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @return Preprocessing results
execute_data_preprocessing <- function(df, target_variable) {
  # Handle missing values
  missing_summary <- sapply(df, function(x) sum(is.na(x)))
  
  # Encode categorical variables
  categorical_vars <- names(df)[sapply(df, is.character)]
  encoding_info <- list()
  
  for (var in categorical_vars) {
    if (var != target_variable) {
      df[[var]] <- factor(df[[var]])
      encoding_info[[var]] <- list(
        original_type = "character",
        encoded_type = "factor",
        levels = levels(df[[var]]),
        level_count = length(levels(df[[var]]))
      )
    }
  }
  
  # Scale numeric variables (excluding target)
  numeric_vars <- names(df)[sapply(df, is.numeric)]
  scaling_info <- list()
  
  for (var in numeric_vars) {
    if (var != target_variable) {
      # Z-score standardization
      df[[var]] <- scale(df[[var]])
      scaling_info[[var]] <- list(
        method = "z_score",
        mean = attr(df[[var]], "scaled:center"),
        sd = attr(df[[var]], "scaled:scale")
      )
    }
  }
  
  # Store preprocessed data
  .GlobalEnv$preprocessed_data <- df
  
  list(
    success = TRUE,
    operation = "data_preprocessing",
    missing_summary = missing_summary,
    encoding_info = encoding_info,
    scaling_info = scaling_info,
    message = "Data preprocessing completed successfully"
  )
}

#' Execute Dimensionality Reduction
#' @param df Dataframe to analyze
#' @param options Additional options
#' @return Dimensionality reduction results
execute_dimensionality_reduction <- function(df, options) {
  # Select numeric variables for reduction
  numeric_cols <- sapply(df, is.numeric)
  numeric_data <- df[, numeric_cols, drop = FALSE]
  
  # PCA
  pca_result <- prcomp(numeric_data, scale. = TRUE)
  pca_variance <- pca_result$sdev^2 / sum(pca_result$sdev^2)
  
  # t-SNE (if package available)
  tsne_result <- NULL
  if (requireNamespace("Rtsne", quietly = TRUE)) {
    set.seed(123)
    tsne_result <- Rtsne::Rtsne(numeric_data, perplexity = min(30, nrow(numeric_data) - 1))
  }
  
  # UMAP (if package available)
  umap_result <- NULL
  if (requireNamespace("umap", quietly = TRUE)) {
    set.seed(123)
    umap_result <- umap::umap(numeric_data)
  }
  
  # Store results
  .GlobalEnv$dimensionality_reduction_results <- list(
    pca = pca_result,
    tsne = tsne_result,
    umap = umap_result
  )
  
  list(
    success = TRUE,
    operation = "dimensionality_reduction",
    pca_variance_explained = cumsum(pca_variance),
    tsne_available = !is.null(tsne_result),
    umap_available = !is.null(umap_result),
    message = "Dimensionality reduction completed successfully"
  )
}

#' Execute Linear Regression
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @param options Additional options
#' @return Linear regression results with interpretability
execute_linear_regression <- function(df, target_variable, options) {
  # Prepare formula
  features <- names(df)[names(df) != target_variable]
  formula_str <- paste(target_variable, "~", paste(features, collapse = " + "))
  formula_obj <- as.formula(formula_str)
  
  # Train model
  model <- lm(formula_obj, data = df)
  
  # Model summary
  model_summary <- summary(model)
  
  # Feature importance (coefficient magnitudes)
  coefficients <- coef(model)
  feature_importance <- data.frame(
    feature = names(coefficients),
    coefficient = coefficients,
    abs_coefficient = abs(coefficients),
    stringsAsFactors = FALSE
  )
  feature_importance <- feature_importance[order(-feature_importance$abs_coefficient), ]
  
  # Residuals analysis
  residuals_analysis <- list(
    mean_residual = mean(resid(model)),
    residual_sd = sd(resid(model)),
    normality_test = shapiro.test(resid(model))$p.value
  )
  
  # Store model
  .GlobalEnv$linear_regression_model <- model
  
  list(
    success = TRUE,
    operation = "linear_regression",
    model = model,
    r_squared = model_summary$r.squared,
    adjusted_r_squared = model_summary$adj.r.squared,
    feature_importance = feature_importance,
    residuals_analysis = residuals_analysis,
    message = "Linear regression completed successfully"
  )
}

#' Execute Logistic Regression
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @param options Additional options
#' @return Logistic regression results with interpretability
execute_logistic_regression <- function(df, target_variable, options) {
  # Ensure target is binary
  target_data <- df[[target_variable]]
  if (length(unique(target_data)) != 2) {
    stop("Logistic regression requires binary target variable")
  }
  
  # Prepare formula
  features <- names(df)[names(df) != target_variable]
  formula_str <- paste(target_variable, "~", paste(features, collapse = " + "))
  formula_obj <- as.formula(formula_str)
  
  # Train model
  model <- glm(formula_obj, data = df, family = "binomial")
  
  # Model summary
  model_summary <- summary(model)
  
  # Feature importance (odds ratios)
  coefficients <- coef(model)
  odds_ratios <- exp(coefficients)
  feature_importance <- data.frame(
    feature = names(coefficients),
    coefficient = coefficients,
    odds_ratio = odds_ratios,
    abs_coefficient = abs(coefficients),
    stringsAsFactors = FALSE
  )
  feature_importance <- feature_importance[order(-feature_importance$abs_coefficient), ]
  
  # Model performance
  predictions <- predict(model, type = "response")
  predicted_classes <- ifelse(predictions > 0.5, 1, 0)
  accuracy <- mean(predicted_classes == target_data)
  
  # Store model
  .GlobalEnv$logistic_regression_model <- model
  
  list(
    success = TRUE,
    operation = "logistic_regression",
    model = model,
    accuracy = accuracy,
    feature_importance = feature_importance,
    odds_ratios = odds_ratios,
    message = "Logistic regression completed successfully"
  )
}

#' Execute Multinomial Regression
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @param options Additional options
#' @return Multinomial regression results with interpretability
execute_multinomial_regression <- function(df, target_variable, options) {
  # Ensure target has multiple levels
  target_data <- df[[target_variable]]
  if (length(unique(target_data)) < 3) {
    stop("Multinomial regression requires target with 3+ levels")
  }
  
  # Prepare formula
  features <- names(df)[names(df) != target_variable]
  formula_str <- paste(target_variable, "~", paste(features, collapse = " + "))
  formula_obj <- as.formula(formula_str)
  
  # Train model using nnet
  model <- nnet::multinom(formula_obj, data = df, trace = FALSE)
  
  # Model summary
  model_summary <- summary(model)
  
  # Feature importance (coefficient magnitudes)
  coefficients <- coef(model)
  if (is.vector(coefficients)) {
    coefficients <- matrix(coefficients, nrow = 1, dimnames = list(NULL, names(coefficients)))
  }
  
  feature_importance <- data.frame(
    feature = colnames(coefficients),
    mean_coefficient = colMeans(abs(coefficients)),
    max_coefficient = apply(abs(coefficients), 2, max),
    stringsAsFactors = FALSE
  )
  feature_importance <- feature_importance[order(-feature_importance$mean_coefficient), ]
  
  # Model performance
  predictions <- predict(model, type = "class")
  accuracy <- mean(predictions == target_data)
  
  # Store model
  .GlobalEnv$multinomial_regression_model <- model
  
  list(
    success = TRUE,
    operation = "multinomial_regression",
    model = model,
    accuracy = accuracy,
    feature_importance = feature_importance,
    coefficients = coefficients,
    message = "Multinomial regression completed successfully"
  )
}

#' Execute Random Forest
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @param options Additional options
#' @return Random forest results with interpretability
execute_random_forest <- function(df, target_variable, options) {
  # Prepare formula
  features <- names(df)[names(df) != target_variable]
  formula_str <- paste(target_variable, "~", paste(features, collapse = " + "))
  formula_obj <- as.formula(formula_str)
  
  # Determine if classification or regression
  target_data <- df[[target_variable]]
  is_classification <- !is.numeric(target_data) || length(unique(target_data)) <= 10
  
  if (is_classification) {
    # Classification
    model <- randomForest::randomForest(formula_obj, data = df, ntree = 100, importance = TRUE)
    
    # Feature importance
    importance_matrix <- randomForest::importance(model)
    feature_importance <- data.frame(
      feature = rownames(importance_matrix),
      mean_decrease_accuracy = importance_matrix[, "MeanDecreaseAccuracy"],
      mean_decrease_gini = importance_matrix[, "MeanDecreaseGini"],
      stringsAsFactors = FALSE
    )
    feature_importance <- feature_importance[order(-feature_importance$mean_decrease_accuracy), ]
    
    # Model performance
    predictions <- predict(model, type = "class")
    accuracy <- mean(predictions == target_data)
    
    performance_metrics <- list(
      accuracy = accuracy,
      confusion_matrix = table(predictions, target_data)
    )
  } else {
    # Regression
    model <- randomForest::randomForest(formula_obj, data = df, ntree = 100, importance = TRUE)
    
    # Feature importance
    importance_matrix <- randomForest::importance(model)
    feature_importance <- data.frame(
      feature = rownames(importance_matrix),
      percent_inc_mse = importance_matrix[, "%IncMSE"],
      inc_node_purity = importance_matrix[, "IncNodePurity"],
      stringsAsFactors = FALSE
    )
    feature_importance <- feature_importance[order(-feature_importance$percent_inc_mse), ]
    
    # Model performance
    predictions <- predict(model)
    mse <- mean((predictions - target_data)^2)
    r_squared <- 1 - sum((target_data - predictions)^2) / sum((target_data - mean(target_data))^2)
    
    performance_metrics <- list(
      mse = mse,
      r_squared = r_squared,
      rmse = sqrt(mse)
    )
  }
  
  # Store model
  .GlobalEnv$random_forest_model <- model
  
  list(
    success = TRUE,
    operation = "random_forest",
    model = model,
    is_classification = is_classification,
    feature_importance = feature_importance,
    performance_metrics = performance_metrics,
    message = "Random forest completed successfully"
  )
}

#' Execute XGBoost
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @param options Additional options
#' @return XGBoost results with interpretability
execute_xgboost <- function(df, target_variable, options) {
  # Prepare data
  features <- names(df)[names(df) != target_variable]
  X <- df[, features, drop = FALSE]
  y <- df[[target_variable]]
  
  # Determine if classification or regression
  is_classification <- !is.numeric(y) || length(unique(y)) <= 10
  
  # Convert categorical variables to numeric
  for (col in names(X)) {
    if (is.character(X[[col]]) || is.factor(X[[col]])) {
      X[[col]] <- as.numeric(factor(X[[col]]))
    }
  }
  
  # Convert to matrix
  X_matrix <- as.matrix(X)
  
  if (is_classification) {
    # Classification
    if (length(unique(y)) == 2) {
      # Binary classification
      y_numeric <- as.numeric(factor(y)) - 1
      model <- xgboost::xgboost(
        data = X_matrix,
        label = y_numeric,
        nrounds = 100,
        objective = "binary:logistic",
        eval_metric = "logloss",
        verbose = 0
      )
    } else {
      # Multi-class classification
      y_numeric <- as.numeric(factor(y)) - 1
      model <- xgboost::xgboost(
        data = X_matrix,
        label = y_numeric,
        nrounds = 100,
        objective = "multi:softprob",
        num_class = length(unique(y)),
        eval_metric = "mlogloss",
        verbose = 0
      )
    }
    
    # Feature importance
    importance_matrix <- xgboost::xgb.importance(feature_names = features, model = model)
    feature_importance <- data.frame(
      feature = importance_matrix$Feature,
      importance = importance_matrix$Importance,
      stringsAsFactors = FALSE
    )
    feature_importance <- feature_importance[order(-feature_importance$importance), ]
    
    # Model performance
    predictions <- predict(model, X_matrix)
    if (length(unique(y)) == 2) {
      predicted_classes <- ifelse(predictions > 0.5, 1, 0)
      accuracy <- mean(predicted_classes == y_numeric)
    } else {
      predicted_classes <- max.col(matrix(predictions, ncol = length(unique(y)), byrow = TRUE)) - 1
      accuracy <- mean(predicted_classes == y_numeric)
    }
    
    performance_metrics <- list(
      accuracy = accuracy
    )
  } else {
    # Regression
    model <- xgboost::xgboost(
      data = X_matrix,
      label = y,
      nrounds = 100,
      objective = "reg:squarederror",
      eval_metric = "rmse",
      verbose = 0
    )
    
    # Feature importance
    importance_matrix <- xgboost::xgb.importance(feature_names = features, model = model)
    feature_importance <- data.frame(
      feature = importance_matrix$Feature,
      importance = importance_matrix$Importance,
      stringsAsFactors = FALSE
    )
    feature_importance <- feature_importance[order(-feature_importance$importance), ]
    
    # Model performance
    predictions <- predict(model, X_matrix)
    mse <- mean((predictions - y)^2)
    r_squared <- 1 - sum((y - predictions)^2) / sum((y - mean(y))^2)
    
    performance_metrics <- list(
      mse = mse,
      r_squared = r_squared,
      rmse = sqrt(mse)
    )
  }
  
  # Store model
  .GlobalEnv$xgboost_model <- model
  
  list(
    success = TRUE,
    operation = "xgboost",
    model = model,
    is_classification = is_classification,
    feature_importance = feature_importance,
    performance_metrics = performance_metrics,
    message = "XGBoost completed successfully"
  )
}

#' Execute Feature Engineering
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @param options Additional options
#' @return Feature engineering results
execute_feature_engineering <- function(df, target_variable, options) {
  # Create interaction terms for numeric variables
  numeric_features <- names(df)[sapply(df, is.numeric) & names(df) != target_variable]
  
  if (length(numeric_features) >= 2) {
    # Create pairwise interactions
    for (i in 1:(length(numeric_features) - 1)) {
      for (j in (i + 1):length(numeric_features)) {
        interaction_name <- paste(numeric_features[i], numeric_features[j], "interaction", sep = "_")
        df[[interaction_name]] <- df[[numeric_features[i]]] * df[[numeric_features[j]]]
      }
    }
  }
  
  # Create polynomial features for important numeric variables
  if (length(numeric_features) > 0) {
    for (feature in numeric_features[1:min(3, length(numeric_features))]) {
      df[[paste0(feature, "_squared")]] <- df[[feature]]^2
    }
  }
  
  # Store engineered data
  .GlobalEnv$engineered_data <- df
  
  # Calculate new features created (compare with original if available)
  original_cols <- if (exists("original_data", envir = .GlobalEnv)) {
    ncol(get("original_data", envir = .GlobalEnv))
  } else {
    ncol(df)  # Fallback if original not available
  }
  
  list(
    success = TRUE,
    operation = "feature_engineering",
    new_features_created = ncol(df) - original_cols,
    message = "Feature engineering completed successfully"
  )
}

#' Execute Model Comparison
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @param algorithms Selected algorithms
#' @return Model comparison results
execute_model_comparison <- function(df, target_variable, algorithms) {
  # Collect all trained models
  models <- list()
  performance_summary <- list()
  
  # Linear regression
  if (algorithms$linearRegression && exists("linear_regression_model", envir = .GlobalEnv)) {
    models$linear_regression <- get("linear_regression_model", envir = .GlobalEnv)
    performance_summary$linear_regression <- list(
      r_squared = summary(models$linear_regression)$r.squared,
      adjusted_r_squared = summary(models$linear_regression)$adj.r.squared
    )
  }
  
  # Logistic regression
  if (algorithms$logisticRegression && exists("logistic_regression_model", envir = .GlobalEnv)) {
    models$logistic_regression <- get("logistic_regression_model", envir = .GlobalEnv)
    # Calculate accuracy
    predictions <- predict(models$logistic_regression, type = "response")
    predicted_classes <- ifelse(predictions > 0.5, 1, 0)
    actual_classes <- df[[target_variable]]
    accuracy <- mean(predicted_classes == actual_classes)
    performance_summary$logistic_regression <- list(accuracy = accuracy)
  }
  
  # Random forest
  if (algorithms$randomForest && exists("random_forest_model", envir = .GlobalEnv)) {
    models$random_forest <- get("random_forest_model", envir = .GlobalEnv)
    # Extract performance metrics
    if (models$random_forest$is_classification) {
      performance_summary$random_forest <- list(accuracy = models$random_forest$performance_metrics$accuracy)
    } else {
      performance_summary$random_forest <- list(
        r_squared = models$random_forest$performance_metrics$r_squared,
        rmse = models$random_forest$performance_metrics$rmse
      )
    }
  }
  
  # XGBoost
  if (algorithms$xgboost && exists("xgboost_model", envir = .GlobalEnv)) {
    models$xgboost <- get("xgboost_model", envir = .GlobalEnv)
    # Extract performance metrics
    if (models$xgboost$is_classification) {
      performance_summary$xgboost <- list(accuracy = models$xgboost$performance_metrics$accuracy)
    } else {
      performance_summary$xgboost <- list(
        r_squared = models$xgboost$performance_metrics$r_squared,
        rmse = models$xgboost$performance_metrics$rmse
      )
    }
  }
  
  # Find best model
  best_model <- NULL
  best_metric <- -Inf
  
  for (model_name in names(performance_summary)) {
    metrics <- performance_summary[[model_name]]
    if ("r_squared" %in% names(metrics)) {
      if (metrics$r_squared > best_metric) {
        best_metric <- metrics$r_squared
        best_model <- model_name
      }
    } else if ("accuracy" %in% names(metrics)) {
      if (metrics$accuracy > best_metric) {
        best_metric <- metrics$accuracy
        best_model <- model_name
      }
    }
  }
  
  list(
    success = TRUE,
    operation = "model_comparison",
    models_compared = names(models),
    performance_summary = performance_summary,
    best_model = best_model,
    best_metric = best_metric,
    message = "Model comparison completed successfully"
  )
}

#' Execute Results Compilation
#' @param df Dataframe to analyze
#' @param target_variable Target variable
#' @param algorithms Selected algorithms
#' @return Results compilation
execute_results_compilation <- function(df, target_variable, algorithms) {
  # Compile all results
  results <- list(
    dataframe = deparse(substitute(df)),
    target_variable = target_variable,
    algorithms_used = algorithms,
    timestamp = Sys.time(),
    data_summary = list(
      observations = nrow(df),
      features = ncol(df),
      target_type = ifelse(is.numeric(df[[target_variable]]), "numeric", "categorical")
    )
  )
  
  # Add model results
  model_results <- list()
  
  if (algorithms$linearRegression && exists("linear_regression_model", envir = .GlobalEnv)) {
    model_results$linear_regression <- get("linear_regression_model", envir = .GlobalEnv)
  }
  
  if (algorithms$logisticRegression && exists("logistic_regression_model", envir = .GlobalEnv)) {
    model_results$logistic_regression <- get("logistic_regression_model", envir = .GlobalEnv)
  }
  
  if (algorithms$randomForest && exists("random_forest_model", envir = .GlobalEnv)) {
    model_results$random_forest <- get("random_forest_model", envir = .GlobalEnv)
  }
  
  if (algorithms$xgboost && exists("xgboost_model", envir = .GlobalEnv)) {
    model_results$xgboost <- get("xgboost_model", envir = .GlobalEnv)
  }
  
  results$models <- model_results
  
  # Store comprehensive results
  .GlobalEnv$modeling_results <- results
  
  list(
    success = TRUE,
    operation = "results_compilation",
    results = results,
    message = "Results compilation completed successfully"
  )
}

#' Get Next Modeling Step
#' @param dataframe_name Name of the dataframe
#' @param step_info Information about the current step
#' @param target_variable Target variable
#' @param algorithms Selected algorithms
#' @return Next step information
get_next_modeling_step <- function(dataframe_name, step_info, target_variable, algorithms) {
  tryCatch({
    # Get the dataframe
    df <- get(dataframe_name, envir = .GlobalEnv)
    
    # Get the current step info
    current_step_num <- step_info$step
    operation <- step_info$operation
    
    # Execute the current step
    step_result <- execute_modeling_step(df, step_info, target_variable, algorithms, list())
    
    if (step_result$success) {
      # Return the executed step result
      list(
        success = TRUE,
        step = current_step_num,
        operation = operation,
        description = paste("Completed:", operation),
        code = paste("# Step", current_step_num, "-", operation, "completed successfully"),
        result = step_result
      )
    } else {
      list(
        success = FALSE,
        step = current_step_num,
        operation = operation,
        description = paste("Failed:", operation),
        code = paste("# Step", current_step_num, "-", operation, "failed"),
        error = step_result$error
      )
    }
    
  }, error = function(e) {
    list(
      success = FALSE,
      step = step_info$step,
      operation = step_info$operation,
      description = paste("Error in step:", step_info$operation),
      code = paste("# Error in step:", e$message),
      error = e$message
    )
  })
}

#' Load Required Packages
#' @param packages Vector of package names
load_packages <- function(packages) {
  for (pkg in packages) {
    if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
      tryCatch({
        install.packages(pkg, dependencies = TRUE)
        library(pkg, character.only = TRUE)
      }, error = function(e) {
        warning(paste("Failed to install/load package:", pkg, "- Error:", e$message))
      })
    }
  }
}
