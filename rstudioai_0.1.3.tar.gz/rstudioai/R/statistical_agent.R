# Statistical Analysis Agent for RStudio AI
# Provides comprehensive statistical testing with intelligent test selection

#' Start Statistical Analysis Agent
#' @param dataframe_name Name of the dataframe to analyze
#' @param analysis_options List of selected analysis types
#' @param variables List of variables for analysis
#' @param method_options List of method preferences
#' @param custom_inputs List of custom specifications
#' @return List with workflow steps and initial analysis
start_statistical_analysis <- function(dataframe_name, analysis_options, variables, method_options, custom_inputs) {
  tryCatch({
    # Load required packages
    required_packages <- c("dplyr", "ggplot2", "car", "effectsize", "pwr", "nortest")
    load_packages(required_packages)
    
    # Get the dataframe
    df <- get(dataframe_name, envir = .GlobalEnv)
    
    # Validate dataframe
    if (!is.data.frame(df)) {
      stop("Selected object is not a dataframe")
    }
    
    # Create workflow steps based on selected analyses
    workflow_steps <- create_statistical_workflow(analysis_options, variables, method_options)
    
    # Execute first step
    first_step <- execute_statistical_step(df, workflow_steps[[1]], variables, method_options)
    
    # Return workflow information
    list(
      success = TRUE,
      dataframe = dataframe_name,
      analysis_options = analysis_options,
      variables = variables,
      method_options = method_options,
      custom_inputs = custom_inputs,
      workflow_steps = workflow_steps,
      current_step = first_step,
      total_steps = length(workflow_steps),
      message = "Statistical analysis agent started successfully"
    )
    
  }, error = function(e) {
    list(
      success = FALSE,
      error = e$message,
      message = paste("Failed to start statistical analysis agent:", e$message)
    )
  })
}

#' Create Statistical Workflow Steps
#' @param analysis_options Selected analysis types
#' @param variables Variable specifications
#' @param method_options Method preferences
#' @return List of workflow steps
create_statistical_workflow <- function(analysis_options, variables, method_options) {
  steps <- list()
  step_counter <- 1
  
  # Data Overview Step
  steps[[step_counter]] <- list(
    step = step_counter,
    operation = "data_overview",
    description = "Analyzing data structure and generating summary statistics",
    code = "generate_data_overview()"
  )
  step_counter <- step_counter + 1
  
  # Distribution Analysis Step
  if (analysis_options$basicStatistics) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "distribution_analysis",
      description = "Analyzing variable distributions and checking assumptions",
      code = "analyze_distributions()"
    )
    step_counter <- step_counter + 1
  }
  
  # Group Comparisons Step
  if (analysis_options$groupComparisons) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "group_comparisons",
      description = "Performing group comparison tests (t-tests, ANOVA)",
      code = "perform_group_comparisons()"
    )
    step_counter <- step_counter + 1
  }
  
  # Before/After Analysis Step
  if (analysis_options$beforeAfterAnalysis) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "before_after_analysis",
      description = "Analyzing paired data and before/after comparisons",
      code = "perform_paired_analysis()"
    )
    step_counter <- step_counter + 1
  }
  
  # Effect Size Analysis Step
  if (analysis_options$effectSizeAnalysis) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "effect_size_analysis",
      description = "Calculating effect sizes and confidence intervals",
      code = "calculate_effect_sizes()"
    )
    step_counter <- step_counter + 1
  }
  
  # Power Analysis Step
  if (analysis_options$powerAnalysis) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "power_analysis",
      description = "Performing power analysis and sample size calculations",
      code = "perform_power_analysis()"
    )
    step_counter <- step_counter + 1
  }
  
  # Multiple Testing Correction Step
  if (analysis_options$multipleTestingCorrection) {
    steps[[step_counter]] <- list(
      step = step_counter,
      operation = "multiple_testing_correction",
      description = "Applying multiple testing corrections",
      code = "apply_multiple_testing_corrections()"
    )
    step_counter <- step_counter + 1
  }
  
  # Results Compilation Step
  steps[[step_counter]] <- list(
    step = step_counter,
    operation = "results_compilation",
    description = "Compiling final results and generating report",
    code = "compile_statistical_results()"
  )
  
  return(steps)
}

#' Execute Statistical Analysis Step
#' @param df Dataframe to analyze
#' @param step_info Step information
#' @param variables Variable specifications
#' @param method_options Method preferences
#' @return Step execution result
execute_statistical_step <- function(df, step_info, variables, method_options) {
  tryCatch({
    operation <- step_info$operation
    
    switch(operation,
      "data_overview" = execute_data_overview(df),
      "distribution_analysis" = execute_distribution_analysis(df, variables),
      "group_comparisons" = execute_group_comparisons(df, variables, method_options),
      "before_after_analysis" = execute_before_after_analysis(df, variables, method_options),
      "effect_size_analysis" = execute_effect_size_analysis(df, variables),
      "power_analysis" = execute_power_analysis(df, variables, method_options),
      "multiple_testing_correction" = execute_multiple_testing_correction(df, variables),
      "results_compilation" = execute_results_compilation(df, variables),
      stop("Unknown operation: ", operation)
    )
    
  }, error = function(e) {
    list(
      success = FALSE,
      error = e$message,
      step = step_info$step,
      operation = operation
    )
  })
}

#' Execute Data Overview Step
#' @param df Dataframe to analyze
#' @return Data overview results
execute_data_overview <- function(df) {
  # Basic structure information
  structure_info <- list(
    dimensions = dim(df),
    variable_count = ncol(df),
    observation_count = nrow(df),
    memory_usage = object.size(df)
  )
  
  # Summary statistics for all variables
  summary_stats <- list()
  for (col in names(df)) {
    if (is.numeric(df[[col]])) {
      summary_stats[[col]] <- summary(df[[col]])
    } else {
      summary_stats[[col]] <- table(df[[col]])
    }
  }
  
  # Data types
  data_types <- sapply(df, class)
  
  # Missing data assessment
  missing_data <- sapply(df, function(x) sum(is.na(x)))
  missing_percentage <- sapply(df, function(x) round(mean(is.na(x)) * 100, 2))
  
  list(
    success = TRUE,
    step = 1,
    operation = "data_overview",
    results = list(
      structure = structure_info,
      summary_statistics = summary_stats,
      data_types = data_types,
      missing_data = missing_data,
      missing_percentage = missing_percentage
    ),
    message = "Data overview completed successfully"
  )
}

#' Execute Distribution Analysis Step
#' @param df Dataframe to analyze
#' @param variables Variable specifications
#' @return Distribution analysis results
execute_distribution_analysis <- function(df, variables) {
  results <- list()
  
  # Analyze each continuous variable
  continuous_vars <- names(df)[sapply(df, is.numeric)]
  
  for (var in continuous_vars) {
    var_data <- df[[var]]
    var_data_clean <- na.omit(var_data)
    
    if (length(var_data_clean) > 3) {
      # Normality test (Shapiro-Wilk for small samples, Kolmogorov-Smirnov for large)
      if (length(var_data_clean) < 5000) {
        normality_test <- shapiro.test(var_data_clean)
        normality_method <- "Shapiro-Wilk"
      } else {
        normality_test <- ks.test(var_data_clean, "pnorm", mean(var_data_clean), sd(var_data_clean))
        normality_method <- "Kolmogorov-Smirnov"
      }
      
      # Skewness and kurtosis
      skewness <- moments::skewness(var_data_clean)
      kurtosis <- moments::kurtosis(var_data_clean)
      
      # Outlier detection using IQR method
      q1 <- quantile(var_data_clean, 0.25)
      q3 <- quantile(var_data_clean, 0.75)
      iqr <- q3 - q1
      lower_bound <- q1 - 1.5 * iqr
      upper_bound <- q3 + 1.5 * iqr
      outliers <- var_data_clean[var_data_clean < lower_bound | var_data_clean > upper_bound]
      
      results[[var]] <- list(
        normality_test = list(
          method = normality_method,
          statistic = normality_test$statistic,
          p_value = normality_test$p.value,
          is_normal = normality_test$p.value > 0.05
        ),
        distribution_characteristics = list(
          mean = mean(var_data_clean),
          median = median(var_data_clean),
          sd = sd(var_data_clean),
          skewness = skewness,
          kurtosis = kurtosis
        ),
        outlier_analysis = list(
          outlier_count = length(outliers),
          outlier_percentage = round(length(outliers) / length(var_data_clean) * 100, 2),
          outlier_values = if(length(outliers) > 0) outliers else NULL
        )
      )
    }
  }
  
  list(
    success = TRUE,
    step = 2,
    operation = "distribution_analysis",
    results = results,
    message = "Distribution analysis completed successfully"
  )
}

#' Execute Group Comparisons Step
#' @param df Dataframe to analyze
#' @param variables Variable specifications
#' @param method_options Method preferences
#' @return Group comparison results
execute_group_comparisons <- function(df, variables, method_options) {
  results <- list()
  
  # Get comparison specifications
  continuous_var <- variables$continuous_variable
  grouping_var <- variables$grouping_variable
  
  if (is.null(continuous_var) || is.null(grouping_var)) {
    stop("Both continuous and grouping variables must be specified")
  }
  
  # Check if variables exist
  if (!continuous_var %in% names(df)) stop("Continuous variable not found in dataframe")
  if (!grouping_var %in% names(df)) stop("Grouping variable not found in dataframe")
  
  # Get unique groups
  groups <- unique(df[[grouping_var]])
  group_count <- length(groups)
  
  if (group_count < 2) {
    stop("Grouping variable must have at least 2 levels")
  }
  
  # Perform appropriate test based on group count
  if (group_count == 2) {
    # Two groups - T-test or Z-test
    test_result <- perform_two_group_test(df, continuous_var, grouping_var, method_options)
  } else {
    # Multiple groups - ANOVA
    test_result <- perform_anova_test(df, continuous_var, grouping_var, method_options)
  }
  
  results$test_type <- test_result$test_type
  results$test_result <- test_result$result
  results$assumptions <- test_result$assumptions
  results$effect_size <- test_result$effect_size
  
  list(
    success = TRUE,
    step = 3,
    operation = "group_comparisons",
    results = results,
    message = "Group comparison analysis completed successfully"
  )
}

#' Perform Two Group Test (T-test or Z-test)
#' @param df Dataframe
#' @param continuous_var Continuous variable name
#' @param grouping_var Grouping variable name
#' @param method_options Method preferences
#' @return Test results
perform_two_group_test <- function(df, continuous_var, grouping_var, method_options) {
  # Split data by groups
  group1_data <- df[[continuous_var]][df[[grouping_var]] == levels(factor(df[[grouping_var]]))[1]]
  group2_data <- df[[continuous_var]][df[[grouping_var]] == levels(factor(df[[grouping_var]]))[2]]
  
  # Remove NA values
  group1_data <- na.omit(group1_data)
  group2_data <- na.omit(group2_data)
  
  # Check assumptions
  assumptions <- check_test_assumptions(group1_data, group2_data)
  
  # Determine test type
  if (assumptions$use_parametric) {
    if (assumptions$large_sample) {
      # Z-test for large samples
      test_result <- perform_z_test(group1_data, group2_data)
      test_type <- "Z-test"
    } else {
      # T-test for smaller samples
      test_result <- perform_t_test(group1_data, group2_data, assumptions$equal_variance)
      test_type <- "T-test"
    }
  } else {
    # Non-parametric alternative
    test_result <- perform_mann_whitney_test(group1_data, group2_data)
    test_type <- "Mann-Whitney U test"
  }
  
  # Calculate effect size
  effect_size <- calculate_cohens_d(group1_data, group2_data)
  
  list(
    test_type = test_type,
    result = test_result,
    assumptions = assumptions,
    effect_size = effect_size
  )
}

#' Perform Z-Test
#' @param group1_data First group data
#' @param group2_data Second group data
#' @return Z-test results
perform_z_test <- function(group1_data, group2_data) {
  n1 <- length(group1_data)
  n2 <- length(group2_data)
  
  mean1 <- mean(group1_data)
  mean2 <- mean(group2_data)
  
  var1 <- var(group1_data)
  var2 <- var(group2_data)
  
  # Pooled standard error
  pooled_se <- sqrt(var1/n1 + var2/n2)
  
  # Z-statistic
  z_stat <- (mean1 - mean2) / pooled_se
  
  # P-value (two-tailed)
  p_value <- 2 * (1 - pnorm(abs(z_stat)))
  
  # Confidence interval (95%)
  ci_lower <- (mean1 - mean2) - 1.96 * pooled_se
  ci_upper <- (mean1 - mean2) + 1.96 * pooled_se
  
  list(
    z_statistic = z_stat,
    p_value = p_value,
    mean_difference = mean1 - mean2,
    confidence_interval = c(ci_lower, ci_upper),
    group1_stats = list(n = n1, mean = mean1, sd = sqrt(var1)),
    group2_stats = list(n = n2, mean = mean2, sd = sqrt(var2))
  )
}

#' Perform T-Test
#' @param group1_data First group data
#' @param group2_data Second group data
#' @param equal_variance Whether to assume equal variances
#' @return T-test results
perform_t_test <- function(group1_data, group2_data, equal_variance = FALSE) {
  if (equal_variance) {
    # Equal variance t-test
    test_result <- t.test(group1_data, group2_data, var.equal = TRUE)
  } else {
    # Welch's t-test (unequal variance)
    test_result <- t.test(group1_data, group2_data, var.equal = FALSE)
  }
  
  list(
    t_statistic = test_result$statistic,
    p_value = test_result$p.value,
    degrees_of_freedom = test_result$parameter,
    mean_difference = test_result$estimate[1] - test_result$estimate[2],
    confidence_interval = test_result$conf.int,
    group1_stats = list(n = length(group1_data), mean = test_result$estimate[1]),
    group2_stats = list(n = length(group2_data), mean = test_result$estimate[2])
  )
}

#' Perform Mann-Whitney U Test
#' @param group1_data First group data
#' @param group2_data Second group data
#' @return Mann-Whitney test results
perform_mann_whitney_test <- function(group1_data, group2_data) {
  test_result <- wilcox.test(group1_data, group2_data, alternative = "two.sided")
  
  # Calculate effect size (r = Z/sqrt(N))
  n_total <- length(group1_data) + length(group2_data)
  z_stat <- qnorm(test_result$p.value / 2)
  effect_size_r <- abs(z_stat) / sqrt(n_total)
  
  list(
    w_statistic = test_result$statistic,
    p_value = test_result$p.value,
    effect_size_r = effect_size_r,
    group1_stats = list(n = length(group1_data), median = median(group1_data)),
    group2_stats = list(n = length(group2_data), median = median(group2_data))
  )
}

#' Check Test Assumptions
#' @param group1_data First group data
#' @param group2_data Second group data
#' @return Assumption check results
check_test_assumptions <- function(group1_data, group2_data) {
  # Normality check
  normality1 <- shapiro.test(group1_data)$p.value > 0.05
  normality2 <- shapiro.test(group2_data)$p.value > 0.05
  both_normal <- normality1 && normality2
  
  # Sample size check for Z-test
  large_sample <- length(group1_data) >= 30 && length(group2_data) >= 30
  
  # Equal variance check (Levene's test equivalent)
  all_data <- c(group1_data, group2_data)
  groups <- factor(rep(c("group1", "group2"), c(length(group1_data), length(group2_data))))
  
  # Simple variance ratio test
  var1 <- var(group1_data)
  var2 <- var(group2_data)
  f_stat <- max(var1, var2) / min(var1, var2)
  df1 <- max(length(group1_data) - 1, length(group2_data) - 1)
  df2 <- min(length(group1_data) - 1, length(group2_data) - 1)
  p_value <- 2 * (1 - pf(f_stat, df1, df2))
  equal_variance <- p_value > 0.05
  
  # Decision logic
  use_parametric <- both_normal && equal_variance
  
  list(
    normality_group1 = normality1,
    normality_group2 = normality2,
    both_normal = both_normal,
    equal_variance = equal_variance,
    large_sample = large_sample,
    use_parametric = use_parametric,
    recommendation = if(use_parametric) "Use parametric test" else "Use non-parametric test"
  )
}

#' Calculate Cohen's d Effect Size
#' @param group1_data First group data
#' @param group2_data Second group data
#' @return Effect size results
calculate_cohens_d <- function(group1_data, group2_data) {
  n1 <- length(group1_data)
  n2 <- length(group2_data)
  
  mean1 <- mean(group1_data)
  mean2 <- mean(group2_data)
  
  # Pooled standard deviation
  pooled_sd <- sqrt(((n1 - 1) * var(group1_data) + (n2 - 1) * var(group2_data)) / (n1 + n2 - 2))
  
  # Cohen's d
  cohens_d <- (mean1 - mean2) / pooled_sd
  
  # Effect size interpretation
  effect_size_interpretation <- if(abs(cohens_d) < 0.2) "Negligible" else
                               if(abs(cohens_d) < 0.5) "Small" else
                               if(abs(cohens_d) < 0.8) "Medium" else "Large"
  
  list(
    cohens_d = cohens_d,
    interpretation = effect_size_interpretation,
    pooled_sd = pooled_sd,
    mean_difference = mean1 - mean2
  )
}

#' Load Required Packages
#' @param packages Vector of package names
load_packages <- function(packages) {
  for (pkg in packages) {
    if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
      install.packages(pkg, dependencies = TRUE)
      library(pkg, character.only = TRUE)
    }
  }
}

# Additional functions for other analysis types would go here...
# (ANOVA, paired tests, power analysis, multiple testing correction)

#' Get Next Statistical Analysis Step
#' @param dataframe_name Name of the dataframe
#' @param step_info Information about the current step
#' @param variables Variable specifications
#' @param method_options Method preferences
#' @return Next step information
get_next_statistical_step <- function(dataframe_name, step_info, variables, method_options) {
  # This function would be called by the WebSocket handler
  # to get the next step in the statistical analysis workflow
  
  # For now, return a placeholder
  list(
    success = TRUE,
    step = step_info$step + 1,
    description = "Next statistical analysis step",
    code = "execute_next_statistical_step()"
  )
}
