#' WebSocket Message Handlers
#' 
#' This module handles all WebSocket communication and message routing,
#' using the proven execution engine for reliable code execution.

#' Handle WebSocket messages
#'
#' @param message The WebSocket message
#' @return Response to send back
handle_websocket_message <- function(message) {
  action <- message$action
  
  switch(action,
    "get_dataframes" = {
      dataframes <- get_available_dataframes()
      list(
        action = "dataframes",
        data = dataframes
      )
    },
    
    "get_dataframe_info" = {
      if(is.null(message$dataframe)) {
        return(list(action = "error", message = "Dataframe name required"))
      }
      
      info <- get_dataframe_info(message$dataframe)
      list(
        action = "dataframe_info",
        data = info
      )
    },
    
    "start_cleaning_agent" = {
      if(is.null(message$dataframe) || is.null(message$na_handling)) {
        return(list(action = "error", message = "Dataframe and NA handling required"))
      }
      
      # Create workflow ID
      workflow_id <- paste0("cleaning_", format(Sys.time(), "%Y-%m-%d %H:%M:%S.%f"))
      
      # Get workflow steps
      workflow_steps <- get_cleaning_workflow_steps()
      
      list(
        action = "agent_started",
        data = list(
          success = TRUE,
          message = "Data Cleaning Agent started successfully",
          workflow_id = workflow_id,
          dataframe = message$dataframe,
          na_handling = message$na_handling,
          total_steps = length(workflow_steps),
          workflow_steps = workflow_steps
        )
      )
    },
    
    "execute_agent_step" = {
      if(is.null(message$step) || is.null(message$dataframe) || is.null(message$na_handling)) {
        return(list(action = "error", message = "Step, dataframe, and NA handling required"))
      }
      
      # Get workflow steps
      workflow_steps <- get_cleaning_workflow_steps()
      
      # Find the requested step
      step_index <- message$step
      if(step_index < 1 || step_index > length(workflow_steps)) {
        return(list(action = "error", message = "Invalid step number"))
      }
      
      step_info <- workflow_steps[[step_index]]
      
      # Load execution settings
      settings <- load_execution_settings()
      
      # Execute the step
      result <- execute_workflow_step(step_info, message$dataframe, message$na_handling, settings)
      
      # Return the result
      list(
        action = "agent_step",
        data = list(
          step = result$step,
          total_steps = length(workflow_steps),
          description = result$description,
          operation = result$operation,
          code = result$code,
          success = result$success,
          output = result$output,
          error = result$error,
          plot = result$plot,
          completed = (result$step == length(workflow_steps))
        )
      )
    },
    
    "execute_code" = {
      if(is.null(message$code)) {
        return(list(action = "error", message = "Code required"))
      }
      
      # Load execution settings
      settings <- load_execution_settings()
      
      # Execute the code using our proven execution engine
      result <- execute_code_in_session(message$code, settings)
      
      # Return the result
      list(
        action = "executed",
        status = if(result$success) "success" else "error",
        result = result$result,
        output = result$output,
        error = if(!result$success) result$error else NULL,
        plot = result$plot
      )
    },
    
    "get_last_error" = {
      # This is now handled by our execution engine
      list(
        action = "last_error",
        message = "No error - use execute_code for execution"
      )
    },
    
    # Default case
    list(
      action = "error",
      message = paste("Unknown action:", action)
    )
  )
}

#' Start WebSocket server
#'
#' @param port Port to run the server on
#' @return WebSocket server instance
start_websocket_server <- function(port = 8889) {
  # Load required libraries
  if (!requireNamespace("websocket", quietly = TRUE)) {
    stop("websocket package is required")
  }
  
  # Create WebSocket server
  server <- websocket::WebSocketServer$new(
    port = port,
    onMessage = function(ws, message) {
      tryCatch({
        # Parse the message
        parsed_message <- jsonlite::fromJSON(message)
        
        # Handle the message
        response <- handle_websocket_message(parsed_message)
        
        # Send response back
        ws$send(jsonlite::toJSON(response, auto_unbox = TRUE))
        
      }, error = function(e) {
        # Send error response
        error_response <- list(
          action = "error",
          message = paste("Error processing message:", e$message)
        )
        ws$send(jsonlite::toJSON(error_response, auto_unbox = TRUE))
      })
    }
  )
  
  cat("WebSocket server started on port", port, "\n")
  return(server)
}

#' Stop WebSocket server
#'
#' @param server WebSocket server instance
stop_websocket_server <- function(server) {
  if (!is.null(server)) {
    server$stop()
    cat("WebSocket server stopped\n")
  }
}
