# Transformation Agent for RStudio AI
# Handles data transformations like log/sqrt, new variables, merging, etc.

library(base64enc)

# Get available dataframes for transformation
get_available_dataframes <- function() {
  objects <- ls(envir = .GlobalEnv)
  dataframes <- objects[sapply(objects, function(x) {
    obj <- get(x, envir = .GlobalEnv)
    is.data.frame(obj) && nrow(obj) > 0 && ncol(obj) > 0
  })]
  return(dataframes)
}

# Get dataframe information for transformation planning
get_dataframe_info <- function(dataframe_name) {
  tryCatch({
    df <- get(dataframe_name, envir = .GlobalEnv)
    
    if (!is.data.frame(df)) {
      return(list(exists = FALSE, error = "Object is not a dataframe"))
    }
    
    # Get column information
    column_info <- list()
    numeric_cols <- c()
    categorical_cols <- c()
    date_cols <- c()
    
    for (col in names(df)) {
      col_data <- df[[col]]
      
      # Determine column type
      if (is.numeric(col_data)) {
        numeric_cols <- c(numeric_cols, col)
        # Check for skewness and distribution
        if (length(na.omit(col_data)) > 3) {
          skewness <- mean((col_data - mean(col_data, na.rm = TRUE))^3, na.rm = TRUE) / 
                     (sd(col_data, na.rm = TRUE)^3)
          column_info[[col]] <- list(
            type = "numeric",
            missing = sum(is.na(col_data)),
            unique = length(unique(col_data)),
            min = min(col_data, na.rm = TRUE),
            max = max(col_data, na.rm = TRUE),
            mean = mean(col_data, na.rm = TRUE),
            median = median(col_data, na.rm = TRUE),
            skewness = round(skewness, 3),
            needs_transformation = abs(skewness) > 1
          )
        } else {
          column_info[[col]] <- list(
            type = "numeric",
            missing = sum(is.na(col_data)),
            unique = length(unique(col_data)),
            min = min(col_data, na.rm = TRUE),
            max = max(col_data, na.rm = TRUE),
            mean = mean(col_data, na.rm = TRUE),
            median = median(col_data, na.rm = TRUE),
            skewness = NA,
            needs_transformation = FALSE
          )
        }
      } else if (is.factor(col_data) || is.character(col_data)) {
        categorical_cols <- c(categorical_cols, col)
        unique_values <- unique(col_data)
        column_info[[col]] <- list(
          type = "categorical",
          missing = sum(is.na(col_data)),
          unique = length(unique_values),
          levels = if(length(unique_values) <= 20) as.character(unique_values) else paste(length(unique_values), "unique values"),
          most_common = names(sort(table(col_data), decreasing = TRUE))[1]
        )
      } else if (inherits(col_data, "Date") || inherits(col_data, "POSIXt")) {
        date_cols <- c(date_cols, col)
        column_info[[col]] <- list(
          type = "date",
          missing = sum(is.na(col_data)),
          unique = length(unique(col_data)),
          min_date = as.character(min(col_data, na.rm = TRUE)),
          max_date = as.character(max(col_data, na.rm = TRUE))
        )
      } else {
        column_info[[col]] <- list(
          type = "other",
          missing = sum(is.na(col_data)),
          unique = length(unique(col_data))
        )
      }
    }
    
               # Calculate size in MB
           size_mb <- round(as.numeric(object.size(df)) / (2^20), 2)
    
    return(list(
      exists = TRUE,
      name = dataframe_name,
      nrow = nrow(df),
      ncol = ncol(df),
      size_mb = size_mb,
      column_info = column_info,
      numeric_cols = numeric_cols,
      categorical_cols = categorical_cols,
      date_cols = date_cols
    ))
    
  }, error = function(e) {
    return(list(exists = FALSE, error = e$message))
  })
}

# Start transformation agent
start_transformation_agent <- function(dataframe, transformation_options, method_options = NULL, custom_inputs = NULL) {
  tryCatch({
    # Validate dataframe exists
    if (!exists(dataframe, envir = .GlobalEnv)) {
      return(list(success = FALSE, error = "Dataframe not found"))
    }
    
    df <- get(dataframe, envir = .GlobalEnv)
    if (!is.data.frame(df)) {
      return(list(success = FALSE, error = "Object is not a dataframe"))
    }
    
    # Build workflow steps based on selected options
    workflow_steps <- list()
    step_num <- 1
    
    # Distribution Analysis
    if (transformation_options$distributionAnalysis) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Analyze variable distributions and identify transformation needs",
        operation = "distribution_analysis"
      )
      step_num <- step_num + 1
    }
    
    # Mathematical Transformations
    if (transformation_options$mathematicalTransformations) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Apply mathematical transformations (log, sqrt, power)",
        operation = "mathematical_transformations"
      )
      step_num <- step_num + 1
    }
    
    # New Variables
    if (transformation_options$newVariables) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Create new variables from existing ones",
        operation = "new_variables"
      )
      step_num <- step_num + 1
    }
    
    # Categorical Transformations
    if (transformation_options$categoricalTransformations) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Transform categorical variables (recode, combine, dummy)",
        operation = "categorical_transformations"
      )
      step_num <- step_num + 1
    }
    
    # Date/Time Transformations
    if (transformation_options$dateTimeTransformations) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Extract date/time components and create time variables",
        operation = "datetime_transformations"
      )
      step_num <- step_num + 1
    }
    
    # Merging & Combining
    if (transformation_options$mergingCombining) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Merge variables and reshape data structure",
        operation = "merging_combining"
      )
      step_num <- step_num + 1
    }
    
    # Aggregation & Grouping
    if (transformation_options$aggregationGrouping) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Create group summaries and rolling statistics",
        operation = "aggregation_grouping"
      )
      step_num <- step_num + 1
    }
    
    # Statistical Transformations
    if (transformation_options$statisticalTransformations) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Apply statistical transformations (z-score, normalization)",
        operation = "statistical_transformations"
      )
      step_num <- step_num + 1
    }
    
    # Text Transformations
    if (transformation_options$textTransformations) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Transform text variables (case, patterns, extraction)",
        operation = "text_transformations"
      )
      step_num <- step_num + 1
    }
    
    # Spatial Transformations
    if (transformation_options$spatialTransformations) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Apply spatial and geographic transformations",
        operation = "spatial_transformations"
      )
      step_num <- step_num + 1
    }
    
    # Custom Transformations
    if (transformation_options$customTransformations) {
      workflow_steps[[step_num]] <- list(
        step = step_num,
        description = "Apply custom user-specified transformations",
        operation = "custom_transformations"
      )
      step_num <- step_num + 1
    }
    
    if (length(workflow_steps) == 0) {
      return(list(success = FALSE, error = "No transformation options selected"))
    }
    
    # Generate first step code
    first_step_code <- generate_transformation_step_code(workflow_steps[[1]], dataframe, method_options, custom_inputs)
    
    # Create workflow ID
    workflow_id <- paste0("transformation_", format(Sys.time(), "%Y-%m-%d %H:%M:%S"))
    
    return(list(
      success = TRUE,
      message = "Transformation Agent started successfully",
      workflow_id = workflow_id,
      dataframe = dataframe,
      transformation_options = transformation_options,
      method_options = method_options,
      custom_inputs = custom_inputs,
      workflow_steps = workflow_steps,
      total_steps = length(workflow_steps),
      current_step = list(
        step = 1,
        description = workflow_steps[[1]]$description,
        operation = workflow_steps[[1]]$operation,
        code = first_step_code
      )
    ))
    
  }, error = function(e) {
    return(list(success = FALSE, error = e$message))
  })
}

# Generate code for a specific transformation step
generate_transformation_step_code <- function(step_info, dataframe, method_options = NULL, custom_inputs = NULL) {
  operation <- step_info$operation
  
  switch(operation,
    "distribution_analysis" = {
      paste0(
        "cat('Distribution Analysis for ", dataframe, "\\n')\n",
        "cat('=====================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "numeric_cols <- sapply(df, is.numeric)\n",
        "if(any(numeric_cols)) {\n",
        "  cat('Numeric Variables:\\n')\n",
        "  for(col in names(df)[numeric_cols]) {\n",
        "    cat('\\n', col, ':\\n')\n",
        "    cat('  Missing:', sum(is.na(df[[col]])), '\\n')\n",
        "    cat('  Mean:', round(mean(df[[col]], na.rm=TRUE), 3), '\\n')\n",
        "    cat('  Median:', round(median(df[[col]], na.rm=TRUE), 3), '\\n')\n",
        "    cat('  SD:', round(sd(df[[col]], na.rm=TRUE), 3), '\\n')\n",
        "    if(length(na.omit(df[[col]])) > 3) {\n",
        "      skewness <- mean((df[[col]] - mean(df[[col]], na.rm=TRUE))^3, na.rm=TRUE) / (sd(df[[col]], na.rm=TRUE)^3)\n",
        "      cat('  Skewness:', round(skewness, 3), '\\n')\n",
        "      if(abs(skewness) > 1) {\n",
        "        cat('  ** SUGGESTION: Consider log/sqrt transformation **\\n')\n",
        "      }\n",
        "    }\n",
        "  }\n",
        "} else {\n",
        "  cat('No numeric columns found\\n')\n",
        "}\n",
        "cat('\\nCategorical Variables:\\n')\n",
        "cat_cols <- sapply(df, function(x) is.factor(x) || is.character(x))\n",
        "if(any(cat_cols)) {\n",
        "  for(col in names(df)[cat_cols]) {\n",
        "    cat('\\n', col, ':\\n')\n",
        "    cat('  Missing:', sum(is.na(df[[col]])), '\\n')\n",
        "    cat('  Unique values:', length(unique(df[[col]])), '\\n')\n",
        "    if(length(unique(df[[col]])) <= 10) {\n",
        "      cat('  Values:', paste(unique(df[[col]]), collapse=', '), '\\n')\n",
        "    }\n",
        "  }\n",
        "} else {\n",
        "  cat('No categorical columns found\\n')\n",
        "}"
      )
    },
    
    "mathematical_transformations" = {
      paste0(
        "cat('Mathematical Transformations for ", dataframe, "\\n')\n",
        "cat('==========================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "numeric_cols <- sapply(df, is.numeric)\n",
        "if(any(numeric_cols)) {\n",
        "  cat('Available numeric columns for transformation:\\n')\n",
        "  cat(paste('  ', names(df)[numeric_cols], collapse='\\n'), '\\n\\n')\n",
        "  cat('Suggested transformations based on data characteristics:\\n')\n",
        "  for(col in names(df)[numeric_cols]) {\n",
        "    if(length(na.omit(df[[col]])) > 3) {\n",
        "      skewness <- mean((df[[col]] - mean(df[[col]], na.rm=TRUE))^3, na.rm=TRUE) / (sd(df[[col]], na.rm=TRUE)^3)\n",
        "      if(abs(skewness) > 1) {\n",
        "        cat('\\n', col, ' (skewness:', round(skewness, 3), '):\\n')\n",
        "        if(min(df[[col]], na.rm=TRUE) > 0) {\n",
        "          cat('  - log transformation: log(', col, ')\\n')\n",
        "        }\n",
        "        cat('  - sqrt transformation: sqrt(', col, ')\\n')\n",
        "        cat('  - power transformation: ', col, '^0.5\\n')\n",
        "      }\n",
        "    }\n",
        "  }\n",
        "} else {\n",
        "  cat('No numeric columns found for mathematical transformations\\n')\n",
        "}"
      )
    },
    
    "new_variables" = {
      paste0(
        "cat('New Variable Creation for ", dataframe, "\\n')\n",
        "cat('====================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "numeric_cols <- sapply(df, is.numeric)\n",
        "cat('Numeric columns available for combinations:\\n')\n",
        "if(length(numeric_cols) >= 2) {\n",
        "  cat(paste('  ', names(df)[numeric_cols], collapse='\\n'), '\\n\\n')\n",
        "  cat('Suggested new variables:\\n')\n",
        "  for(i in 1:(length(numeric_cols)-1)) {\n",
        "    for(j in (i+1):length(numeric_cols)) {\n",
        "      col1 <- names(df)[numeric_cols][i]\n",
        "      col2 <- names(df)[numeric_cols][j]\n",
        "      cat('\\n  ', col1, ' + ', col2, ' (sum)\\n')\n",
        "      cat('  ', col1, ' * ', col2, ' (product)\\n')\n",
        "      cat('  ', col1, ' / ', col2, ' (ratio)\\n')\n",
        "      cat('  (', col1, ' - ', col2, ') / (', col1, ' + ', col2, ') (normalized difference)\\n')\n",
        "    }\n",
        "  }\n",
        "} else {\n",
        "  cat('Need at least 2 numeric columns for combinations\\n')\n",
        "}"
      )
    },
    
    "categorical_transformations" = {
      paste0(
        "cat('Categorical Transformations for ", dataframe, "\\n')\n",
        "cat('=======================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "cat_cols <- sapply(df, function(x) is.factor(x) || is.character(x))\n",
        "if(any(cat_cols)) {\n",
        "  cat('Categorical columns available for transformation:\\n')\n",
        "  for(col in names(df)[cat_cols]) {\n",
        "    cat('\\n', col, ':\\n')\n",
        "    unique_vals <- unique(df[[col]])\n",
        "    cat('  Unique values:', length(unique_vals), '\\n')\n",
        "    if(length(unique_vals) <= 20) {\n",
        "      cat('  Values:', paste(unique_vals, collapse=', '), '\\n')\n",
        "    }\n",
        "    cat('  Missing:', sum(is.na(df[[col]])), '\\n')\n",
        "    if(length(unique_vals) > 10) {\n",
        "      cat('  ** SUGGESTION: Consider combining small categories **\\n')\n",
        "    }\n",
        "  }\n",
        "} else {\n",
        "  cat('No categorical columns found\\n')\n",
        "}"
      )
    },
    
    "datetime_transformations" = {
      paste0(
        "cat('Date/Time Transformations for ", dataframe, "\\n')\n",
        "cat('====================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "date_cols <- sapply(df, function(x) inherits(x, 'Date') || inherits(x, 'POSIXt'))\n",
        "if(any(date_cols)) {\n",
        "  cat('Date/Time columns available for transformation:\\n')\n",
        "  for(col in names(df)[date_cols]) {\n",
        "    cat('\\n', col, ':\\n')\n",
        "    cat('  Type:', class(df[[col]])[1], '\\n')\n",
        "    cat('  Range:', as.character(min(df[[col]], na.rm=TRUE)), 'to', as.character(max(df[[col]], na.rm=TRUE)), '\\n')\n",
        "    cat('  Missing:', sum(is.na(df[[col]])), '\\n')\n",
        "    cat('  Suggested extractions:\\n')\n",
        "    cat('    - Year: year(', col, ')\\n')\n",
        "    cat('    - Month: month(', col, ')\\n')\n",
        "    cat('    - Day: day(', col, ')\\n')\n",
        "    cat('    - Quarter: quarter(', col, ')\\n')\n",
        "    cat('    - Weekday: wday(', col, ')\\n')\n",
        "  }\n",
        "} else {\n",
        "  cat('No date/time columns found\\n')\n",
        "}"
      )
    },
    
    "merging_combining" = {
      paste0(
        "cat('Merging & Combining Variables for ", dataframe, "\\n')\n",
        "cat('==========================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "cat('Available columns for merging/combining:\\n')\n",
        "for(col in names(df)) {\n",
        "  cat('  ', col, ' (', class(df[[col]])[1], ')\\n')\n",
        "}\n",
        "cat('\\nSuggested operations:\\n')\n",
        "cat('  - Combine text columns with paste()\\n')\n",
        "cat('  - Split text columns with separate()\\n')\n",
        "cat('  - Reshape data with pivot_longer() or pivot_wider()\\n')\n",
        "cat('  - Join with other datasets\\n'"
      )
    },
    
    "aggregation_grouping" = {
      paste0(
        "cat('Aggregation & Grouping for ", dataframe, "\\n')\n",
        "cat('====================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "cat_cols <- sapply(df, function(x) is.factor(x) || is.character(x))\n",
        "numeric_cols <- sapply(df, is.numeric)\n",
        "if(any(cat_cols) && any(numeric_cols)) {\n",
        "  cat('Grouping variables (categorical):\\n')\n",
        "  cat(paste('  ', names(df)[cat_cols], collapse='\\n'), '\\n\\n')\n",
        "  cat('Variables to aggregate (numeric):\\n')\n",
        "  cat(paste('  ', names(df)[numeric_cols], collapse='\\n'), '\\n\\n')\n",
        "  cat('Suggested aggregations:\\n')\n",
        "  cat('  - Mean by group\\n')\n",
        "  cat('  - Count by group\\n')\n",
        "  cat('  - Rolling statistics\\n')\n",
        "  cat('  - Cumulative sums\\n')\n",
        "} else {\n",
        "  cat('Need both categorical and numeric columns for grouping\\n')\n",
        "}"
      )
    },
    
    "statistical_transformations" = {
      paste0(
        "cat('Statistical Transformations for ", dataframe, "\\n')\n",
        "cat('=====================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "numeric_cols <- sapply(df, is.numeric)\n",
        "if(any(numeric_cols)) {\n",
        "  cat('Numeric columns available for statistical transformations:\\n')\n",
        "  cat(paste('  ', names(df)[numeric_cols], collapse='\\n'), '\\n\\n')\n",
        "  cat('Suggested transformations:\\n')\n",
        "  for(col in names(df)[numeric_cols]) {\n",
        "    cat('\\n', col, ':\\n')\n",
        "    cat('  - Z-score: scale(', col, ')\\n')\n",
        "    cat('  - Min-max normalization: (', col, ' - min(', col, ')) / (max(', col, ') - min(', col, '))\\n')\n",
        "    cat('  - Robust scaling: (', col, ' - median(', col, ')) / IQR(', col, ')\\n')\n",
        "    cat('  - Rank transformation: rank(', col, ')\\n')\n",
        "  }\n",
        "} else {\n",
        "  cat('No numeric columns found for statistical transformations\\n')\n",
        "}"
      )
    },
    
    "text_transformations" = {
      paste0(
        "cat('Text Transformations for ", dataframe, "\\n')\n",
        "cat('================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "text_cols <- sapply(df, is.character)\n",
        "if(any(text_cols)) {\n",
        "  cat('Text columns available for transformation:\\n')\n",
        "  for(col in names(df)[text_cols]) {\n",
        "    cat('\\n', col, ':\\n')\n",
        "    cat('  Missing:', sum(is.na(df[[col]])), '\\n')\n",
        "    cat('  Unique values:', length(unique(df[[col]])), '\\n')\n",
        "    cat('  Suggested transformations:\\n')\n",
        "    cat('    - Case change: toupper(', col, '), tolower(', col, ')\\n')\n",
        "    cat('    - String replacement: str_replace(', col, ', pattern, replacement)\\n')\n",
        "    cat('    - Pattern extraction: str_extract(', col, ', pattern)\\n')\n",
        "    cat('    - Word count: str_count(', col, ', \\\\w+')\\n')\n",
        "  }\n",
        "} else {\n",
        "  cat('No text columns found\\n')\n",
        "}"
      )
    },
    
    "spatial_transformations" = {
      paste0(
        "cat('Spatial Transformations for ", dataframe, "\\n')\n",
        "cat('==================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "cat('Spatial transformation capabilities:\\n')\n",
        "cat('  - Coordinate transformations\\n')\n",
        "cat('  - Distance calculations\\n')\n",
        "cat('  - Spatial joins\\n')\n",
        "cat('  - Area calculations\\n')\n",
        "cat('\\nNote: Requires spatial packages (sf, sp, rgdal)\\n')\n",
        "cat('Current columns:', paste(names(df), collapse=', '), '\\n'"
      )
    },
    
    "custom_transformations" = {
      paste0(
        "cat('Custom Transformations for ", dataframe, "\\n')\n",
        "cat('==================================\\n\\n')\n",
        "df <- ", dataframe, "\n",
        "cat('Available columns for custom transformations:\\n')\n",
        "for(col in names(df)) {\n",
        "  cat('  ', col, ' (', class(df[[col]])[1], ')\\n')\n",
        "}\n",
        "cat('\\nUse custom_inputs to specify transformation code\\n'"
      )
    },
    
    # Default case
    paste0("cat('Transformation step: ", operation, " for ", dataframe, "\\n')")
  )
}

# Get next transformation step code
get_next_transformation_step_code <- function(step_info, dataframe, method_options = NULL, custom_inputs = NULL) {
  return(generate_transformation_step_code(step_info, dataframe, method_options, custom_inputs))
}
