# This file is part of the standard testthat testing infrastructure
library(testthat)
library(rstudioai)

test_check("rstudioai")
